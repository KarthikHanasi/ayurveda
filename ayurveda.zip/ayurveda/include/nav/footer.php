		<footer>
    		<div class="container">
            <p class="pull-right"><a href="#"><i class="fa fa-arrow-up" style="font-size:40px; color: white; position: relative;top: 25px;" title="top"></i></a></p><br>
            <p class="text-center"> <?php echo date("Y")?> Copyright &copy; All Rights Reserved. www.infynow.com</p>
             <!-- <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p> -->
    		</div>
      	</footer>