<div class="modal fade" id="myModal" style="width: 80%; margin-left: 8%;">
        <div class="modal-dialog">
          <div class="modal-content">

            <!-- Modal body -->
            <div class="modal-body">
              <div class="row">
                <div class="col-sm-4"></div>

                  <div class="col-sm-6">
                  <!-- Modal body.. -->
                        <p><a href="home.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a></p>
                        <p><a href="about.php"><i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;About us</a></p>
                        <p><a href="advertising.php"><i class="fa fa-buysellads"></i>&nbsp;&nbsp;Advertising with us</a></p>
                        <p><a href="list_your_business.php"><i class="fa fa-briefcase"></i>&nbsp;&nbsp;List your Business</a></p>
                        <p><a href="contact_us.php"><i class="fa fa-address-book"></i>&nbsp;&nbsp;Contact us</a></p>
                  </div>

                <div class="col-sm-2"></div>
              </div>
            </div>

          </div>
        </div>
      </div>