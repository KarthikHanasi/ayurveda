

	<div class="header">
        <h2 class="companyName"><span style="font-family: cursive;">Sara</span> Ayurveda</h2>
	     <!-- <button type="button" class="pull-right btnMenu" data-toggle="modal" data-target="#myModal" style="outline:none;">
	     	<i class="fa fa-bars" style="font-size:40px; color: white;"></i>
		    </button> -->
    </div>