<div class="modal fade" id="location">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">Select City</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

          <!-- Modal body -->
          <div class="modal-body">
                  <div class="row">
                    <div class="col-sm-1"></div>
                        <div class="form-group col-sm-10">
                          <label>City:</label>
                          <!-- <input type="text" > -->
                          <select class="form-control" id="txtCity" name="txtCity">
                            <option id="1">BELAGAVI</option>
                            <option id="2">HUBBLLI</option>
                            <option id="3">BAGALKOT</option>

                          </select>
                        </div>
                    <div class="col-sm-1"></div>
                  </div>

                  <div class="row">
                    <div class="col-sm-1"></div>
                        <div class="form-group col-sm-10">
                          <label>Area:</label>
                          <!-- <input type="text" > -->
                          <select class="form-control" id="txtArea" name="txtArea">
                            <option id="1">REX</option>
                            <option id="2">HANUMAN NAGAR</option>
                            <option id="3">RAM NAGAR</option>
                          </select>
                        </div>
                    <div class="col-sm-1"></div>
                  </div>

                  <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal" id="txtSelect">Select</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                  </div>

              </div>

            </div>
          </div>
        </div>